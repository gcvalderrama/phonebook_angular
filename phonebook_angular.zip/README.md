# Phone book UI

## use visual studio code
## npm install to install dependencies
## npm start to initialize the hosting
## I implement the controller and service to read the functionality 

