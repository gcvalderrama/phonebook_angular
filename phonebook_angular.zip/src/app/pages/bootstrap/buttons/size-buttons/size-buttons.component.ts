import { Component } from '@angular/core';

@Component({
  selector: 'ngx-size-buttons',
  styleUrls: ['./size-buttons.component.scss'],
  templateUrl: './size-buttons.component.html',
})
export class SizeButtonsComponent {
}
